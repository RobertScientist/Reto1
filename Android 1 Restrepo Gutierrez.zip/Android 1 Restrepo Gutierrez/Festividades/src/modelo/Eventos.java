package modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Eventos {

    private int codigoEvento;
    private String nombre;
    private String tipoEvento;
    private String fecha;
    private String horaInicio;
    private String horaFin;
    private String lugar;
    private String boleteria;
    private String estado;

    public Eventos(int codigoEvento, String nombre, String tipoEvento, String fecha,
            String horaInicio, String horaFin, String lugar, String boleteria, String estado) {
        this.codigoEvento = codigoEvento;
        this.nombre = nombre;
        this.tipoEvento = tipoEvento;
        this.fecha = fecha;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.lugar = lugar;
        this.boleteria = boleteria;
        this.estado = estado;
    }

    public Eventos(String nombre, String tipoEvento, String fecha,
            String horaInicio, String horaFin, String lugar, String boleteria, String estado) {
        this.nombre = nombre;
        this.tipoEvento = tipoEvento;
        this.fecha = fecha;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.lugar = lugar;
        this.boleteria = boleteria;
        this.estado = estado;
    }

    public Eventos(int codigoEvento) {
        this.codigoEvento = codigoEvento;
    }

    public Eventos() {
    }

    public int getCodigoEvento() {
        return codigoEvento;
    }

    public void setCodigoEvento(int codigoEvento) {
        this.codigoEvento = codigoEvento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipoEvento() {
        return tipoEvento;
    }

    public void setTipoEvento(String tipoEvento) {
        this.tipoEvento = tipoEvento;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public String getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(String horaFin) {
        this.horaFin = horaFin;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getBoleteria() {
        return boleteria;
    }

    public void setBoleteria(String boleteria) {
        this.boleteria = boleteria;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public boolean agregarEvento(Connection conexionDB) {

        boolean respuesta = true;
        String sql = "INSERT INTO tbleventos"
                + "(nombre,"
                + "tipoEvento,"
                + "fecha,"
                + "horaInicio,"
                + "horaFin,"
                + "lugar,"
                + "boleteria,"
                + "estado)"
                + "VALUES ('"
                + nombre + "','"
                + tipoEvento + "','"
                + fecha + "','"
                + horaInicio + "','"
                + horaFin + "','"
                + lugar + "','"
                + boleteria + "','"
                + estado + "');";

        try {
            Statement ejecutarComandoSQL = conexionDB.createStatement();
            ejecutarComandoSQL.executeUpdate(sql);
            System.out.println("Evento agregado con éxito");

        } catch (SQLException ex) {
            respuesta = false;
            System.out.println("Error en la consulta");
            Logger.getLogger(Eventos.class.getName()).log(Level.SEVERE, null, ex);
        }
        return respuesta;
    }

    public boolean actualizarEventos(Connection conexionDB) {

        boolean respuesta = true;

        String sql = "UPDATE tbleventos "
                + "SET codigoEvento = '"
                + codigoEvento + "', "
                + "nombre = '"
                + nombre + "', "
                + "tipoEvento = '"
                + tipoEvento + "', "
                + "fecha = '"
                + fecha + "', "
                + "horaInicio = '"
                + horaInicio + "', "
                + "horaFin = '"
                + horaFin + "', "
                + "lugar = '"
                + lugar + "', "
                + "boleteria = '"
                + boleteria + "', "
                + "estado = '"
                + estado + "' "
                + "WHERE "
                + "codigoEvento = "
                + codigoEvento + ";";

        try {
            Statement ejecutarComandoSQL = conexionDB.createStatement();
            ejecutarComandoSQL.executeUpdate(sql);

        } catch (SQLException ex) {
            respuesta = false;
            System.out.println("Error en la consulta SQL");
            Logger.getLogger(Eventos.class.getName()).log(Level.SEVERE, null, ex);
            return respuesta;
        }
        return respuesta;
    }

    public void eliminarEventos(int codigoE, Connection conexionDB) {

        String sql = "DELETE FROM tbleventos "
                + "WHERE codigoEvento = "
                + codigoE
                + ";";

        try {
            Statement ejecutarComandoSQL = conexionDB.createStatement();
            ejecutarComandoSQL.executeUpdate(sql);
            System.out.println("Evento eleminado con éxito");

        } catch (SQLException ex) {

            System.out.println("Error en la consulta SQL");
            Logger.getLogger(Eventos.class.getName()).log(Level.SEVERE, null, ex);

        }

    }

    public ArrayList mostrarEventos(Connection conexionDB) {

        String consulta = "SELECT * FROM tbleventos;";

        ResultSet datosMySQL;

        ArrayList<Eventos> infoTransformadaJava = new ArrayList<Eventos>();

        try {

            Statement ejecutarComandoSQL = conexionDB.createStatement();

            datosMySQL = ejecutarComandoSQL.executeQuery(consulta);

            while (datosMySQL.next()) {

                Eventos fila = new Eventos(
                        datosMySQL.getInt("codigoEvento"),
                        datosMySQL.getString("nombre"),
                        datosMySQL.getString("tipoEvento"),
                        datosMySQL.getString("fecha"),
                        datosMySQL.getString("horaInicio"),
                        datosMySQL.getString("horaFin"),
                        datosMySQL.getString("lugar"),
                        datosMySQL.getString("boleteria"),
                        datosMySQL.getString("estado")
                );

                infoTransformadaJava.add(fila);
            }
            return infoTransformadaJava;

        } catch (SQLException ex) {

            System.out.println("Fallo en la consulta");
            Logger.getLogger(Eventos.class.getName()).log(Level.SEVERE, null, ex);
        }
        return infoTransformadaJava;
    }

}
