package modelo;

public class Boletas {
    
}
