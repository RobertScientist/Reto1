package controlador;

public class BoletaController {
    
}
