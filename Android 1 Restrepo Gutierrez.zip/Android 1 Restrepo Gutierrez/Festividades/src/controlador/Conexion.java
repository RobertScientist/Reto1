
package controlador;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    
    //Definición de variables de conexión
    String bd = "festividades";
    String URL = "jdbc:mysql://localhost:3306/" + bd;
    /*String usuario = "userFestividades";
    String password = "user2023+";*/
    String usuario = "root";
    String password = "";
    String Driver = "com.mysql.cj.jdbc.Driver";
    Connection cx; //Conector
    
    public Conexion(){
    }
    
    //Metodo para conectar con la BD
    public Connection conectar(){
        try{
            Class.forName(Driver);
            cx = DriverManager.getConnection(URL,usuario,password);
            
        }catch(Exception e){
            e.printStackTrace();
            System.out.println("No se pudo conectar a la BD");
            return null;
        }
        //Retornar objeto de conexión si la conexión fue exitosa
       return cx;
    }
    
    //Método para desconectar de la BD
    /*
    public static void desconectar(Connection conexion){
        try{
            //Cerrar conexión
            if(conexion != null && !conexion.isClosed()){
                conexion.close();
                System.out.println("Desconectado");
            }
        }catch(SQLException e){
            //Imprimir traza del error en intento de conexión a BD
            e.printStackTrace();
        }
    }
    */
    
    //Prueba a la conexión
    public static void main(String[] args) {
        //Instanciar la clase conexión
        Conexion conexion = new Conexion();
        
        //Llamada al método conectar para establecer la conexión
        Connection cx = conexion.conectar();
        
        //Prueba de conexión
        if(cx != null){
            System.out.println("La conexión está funcionando con éxito");
        }else{
            System.out.println("No está funcionando la conexión");
        }
        
    }
    
}
