package controlador;

import java.sql.Connection;
import java.util.ArrayList;
import modelo.Eventos;

public class EventoController {

    public boolean guardarEvento(String nombre, String tipoEvento, String fecha,
            String horaInicio, String horaFin, String lugar, String boleteria, String estado) {

        boolean respuestaController = true;

        Conexion baseDatos = new Conexion();
        Connection conexionActiva = baseDatos.conectar();

        if (baseDatos != null) {
            Eventos miEvento = new Eventos(nombre, tipoEvento, fecha,
                    horaInicio, horaFin, lugar, boleteria, estado);
            boolean respuestaModelo = miEvento.agregarEvento(conexionActiva);
            if (respuestaModelo) {
                return respuestaController;
            } else {
                respuestaController = false;
                return respuestaController;
            }
        } else {
            respuestaController = false;
            return respuestaController;
        }

    }

    /**
     *
     */
    public boolean actualizarEventos(int codigoEvento, String nombre, String tipoEvento, String fecha,
            String horaInicio, String horaFin, String lugar, String boleteria, String estado) {
        
        boolean respuestaController = true;

        Conexion baseDatos = new Conexion();
        Connection conexionActiva = baseDatos.conectar();

        if (baseDatos != null) {
            Eventos miEvento = new Eventos(codigoEvento, nombre, tipoEvento, fecha,
                    horaInicio, horaFin, lugar, boleteria, estado);
            boolean respuestaModelo = miEvento.actualizarEventos(conexionActiva);
            
            if (respuestaModelo) {
                return respuestaController;
            } else {
                respuestaController = false;
                return respuestaController;
            }
        } else {
            respuestaController = false;
            return respuestaController;
        }
        
    }

    public void eliminarEventos(int codigoEVista) {
        
        Conexion baseDatos = new Conexion();
        Connection conexionActiva = baseDatos.conectar();
        
        Eventos miEvento = new Eventos();//Variable Modelo
        miEvento.eliminarEventos(codigoEVista,conexionActiva);
        
    }

    public ArrayList mostrarEventos() {
        Conexion baseDatos = new Conexion();
        Connection conexionActiva = baseDatos.conectar();

        Eventos miEvento = new Eventos();
        return miEvento.mostrarEventos(conexionActiva);
    }

}
