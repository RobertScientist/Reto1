package vista;

import controlador.Conexion;
import controlador.EventoController;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import modelo.Eventos;

public class FrmEventos extends javax.swing.JFrame {

    DefaultTableModel modeloTabla;

    public FrmEventos() {
        initComponents();
        modeloTabla = (DefaultTableModel) tabla.getModel();
        cargarDatosTablaMySQL();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        Nombre = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtNombre = new javax.swing.JEditorPane();
        horaInicio = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtLugar = new javax.swing.JEditorPane();
        cmbAMPMInicio = new javax.swing.JComboBox<>();
        horaFin = new javax.swing.JComboBox<>();
        cmbTipo = new javax.swing.JComboBox<>();
        cmbEstado = new javax.swing.JComboBox<>();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtFecha = new javax.swing.JEditorPane();
        cmbAMPMFin = new javax.swing.JComboBox<>();
        btnEventSi = new javax.swing.JRadioButton();
        btnEventNo = new javax.swing.JRadioButton();
        btnGuardar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        btnEventEliminar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setFont(new java.awt.Font("Segoe UI Emoji", 0, 10)); // NOI18N

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Logo.png"))); // NOI18N
        jLabel1.setText("jLabel1");

        Nombre.setText("Nombre:");

        jLabel3.setText("Tipo:");

        jLabel4.setText("Fecha:");

        jLabel5.setText("Hora fin:");

        jLabel6.setText("Lugar:");

        jLabel7.setText("Hora inicio:");

        jLabel8.setText("Estado:");

        jLabel9.setText("Boleteria:");

        txtNombre.setEnabled(false);
        jScrollPane2.setViewportView(txtNombre);

        horaInicio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        horaInicio.setEnabled(false);

        txtLugar.setEnabled(false);
        jScrollPane3.setViewportView(txtLugar);

        cmbAMPMInicio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "a.m.", "p.m." }));
        cmbAMPMInicio.setEnabled(false);

        horaFin.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        horaFin.setEnabled(false);

        cmbTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "C: Concierto", "D: Desfile" }));
        cmbTipo.setEnabled(false);

        cmbEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Programado", "Ejecutado" }));
        cmbEstado.setEnabled(false);

        txtFecha.setEnabled(false);
        jScrollPane4.setViewportView(txtFecha);

        cmbAMPMFin.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "a.m.", "p.m." }));
        cmbAMPMFin.setEnabled(false);

        btnEventSi.setText("SI");
        btnEventSi.setContentAreaFilled(false);
        btnEventSi.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEventSi.setEnabled(false);
        btnEventSi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEventSiActionPerformed(evt);
            }
        });

        btnEventNo.setText("NO");
        btnEventNo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEventNo.setEnabled(false);
        btnEventNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEventNoActionPerformed(evt);
            }
        });

        btnGuardar.setText("NUEVO");
        btnGuardar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnCancelar.setText("CANCELAR");
        btnCancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCancelar.setEnabled(false);
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnEventEliminar.setText("ELIMINAR");
        btnEventEliminar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnEventEliminar.setEnabled(false);
        btnEventEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEventEliminarActionPerformed(evt);
            }
        });

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Código", "Nombre", "Tipo evento", "Fecha", "Hora inicio", "Hora Fin", "Lugar", "Boletería", "Estado"
            }
        ));
        tabla.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabla);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(btnGuardar)
                                        .addGap(72, 72, 72)
                                        .addComponent(btnEventEliminar)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnCancelar))
                                    .addComponent(cmbEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnEventSi)
                                .addGap(43, 43, 43)
                                .addComponent(btnEventNo))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(horaFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(24, 24, 24)
                                .addComponent(cmbAMPMFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(horaInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(24, 24, 24)
                                .addComponent(cmbAMPMInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cmbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(191, 191, 191)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(223, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(horaInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbAMPMInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(horaFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbAMPMFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEventSi)
                    .addComponent(btnEventNo))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar)
                    .addComponent(btnCancelar)
                    .addComponent(btnEventEliminar))
                .addContainerGap(60, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cambioEstado(boolean estado) {
        txtNombre.setEnabled(estado);
        cmbTipo.setEnabled(estado);
        txtFecha.setEnabled(estado);
        horaInicio.setEnabled(estado);
        cmbAMPMInicio.setEnabled(estado);
        horaFin.setEnabled(estado);
        cmbAMPMFin.setEnabled(estado);
        txtLugar.setEnabled(estado);
        btnEventSi.setEnabled(estado);
        btnEventNo.setEnabled(estado);
        cmbEstado.setEnabled(estado);
        btnCancelar.setEnabled(estado);

    }

    private void borronyCuentaNueva() {
        cambioEstado(false);
        btnGuardar.setText("NUEVO");
        btnCancelar.setEnabled(false);
        txtNombre.setText("");
        txtFecha.setText("");
        txtLugar.setText("");
        btnEventSi.setSelected(false);
        btnEventNo.setSelected(false);
        btnCancelar.setEnabled(false);
    }

    private void limpiarDatosTabla() {
        modeloTabla.setRowCount(0);
    }

    private void cargarDatosTablaMySQL() {
        limpiarDatosTabla();
        EventoController listaEventos = new EventoController();
        ArrayList<Eventos> info = listaEventos.mostrarEventos();
        for (Eventos datos : info) {
            Object[] fila = new Object[9];
            fila[0] = datos.getCodigoEvento();
            fila[1] = datos.getNombre();
            fila[2] = datos.getTipoEvento();
            fila[3] = datos.getFecha();
            fila[4] = datos.getHoraInicio();
            fila[5] = datos.getHoraFin();
            fila[6] = datos.getLugar();
            fila[7] = datos.getBoleteria();
            fila[8] = datos.getEstado();
            modeloTabla.addRow(fila);
        }
    }

    private void btnEventSiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEventSiActionPerformed
        btnEventSi.setSelected(true);
        btnEventNo.setSelected(false);

    }//GEN-LAST:event_btnEventSiActionPerformed

    private void btnEventNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEventNoActionPerformed
        btnEventNo.setSelected(true);
        btnEventSi.setSelected(false);
    }//GEN-LAST:event_btnEventNoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // TODO add your handling code here:

        String tipoEventoLetra = cmbTipo.getSelectedItem().toString();
        char convertirTipoEvento = tipoEventoLetra.charAt(0);
        tipoEventoLetra = String.valueOf(convertirTipoEvento);
        String boleteria;
        if (btnEventSi.isSelected()) {
            boleteria = "Si";
        } else {
            boleteria = "No";
        }

        if (btnGuardar.getText() == "NUEVO") {
            cambioEstado(true);
            btnGuardar.setText("GUARDAR");
            btnCancelar.setEnabled(true);
        } else if (btnGuardar.getText() == "GUARDAR") {
            System.out.println("Empieza el guardado");
            EventoController miNuevoEvento = new EventoController();
            boolean respuestaFinal;
            respuestaFinal = miNuevoEvento.guardarEvento(
                    txtNombre.getText(),
                    tipoEventoLetra,
                    txtFecha.getText(),
                    horaInicio.getSelectedItem().toString() + cmbAMPMInicio.getSelectedItem().toString(),
                    horaFin.getSelectedItem().toString() + cmbAMPMFin.getSelectedItem().toString(),
                    txtLugar.getText(),
                    boleteria,
                    cmbEstado.getSelectedItem().toString()
            );
            if (respuestaFinal) {
                JOptionPane.showMessageDialog(null, "Evento guardado con éxito");
                borronyCuentaNueva();
                btnEventEliminar.setEnabled(false);
                cargarDatosTablaMySQL();
            } else {
                JOptionPane.showMessageDialog(null, "Contacte al admin, hay un error");
                borronyCuentaNueva();
            }

        } else if (btnGuardar.getText() == "ACTUALIZAR") {
            System.out.println("Empieza el proceso de actualizar");
            EventoController miNuevoEvento = new EventoController();
            boolean respuestaFinal;
            respuestaFinal = miNuevoEvento.actualizarEventos(
                    codigoESeleccionado,
                    txtNombre.getText(),
                    tipoEventoLetra,
                    txtFecha.getText(),
                    horaInicio.getSelectedItem().toString() + cmbAMPMInicio.getSelectedItem().toString(),
                    horaFin.getSelectedItem().toString() + cmbAMPMFin.getSelectedItem().toString(),
                    txtLugar.getText(),
                    boleteria,
                    cmbEstado.getSelectedItem().toString()
            );
            if (respuestaFinal) {
                JOptionPane.showMessageDialog(null, "Evento actualizado con éxito");
                borronyCuentaNueva();
                cargarDatosTablaMySQL();
            } else {
                JOptionPane.showMessageDialog(null, "Contacte al admin, hay un error");
                borronyCuentaNueva();
            }
        }

    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        // TODO add your handling code here:
        borronyCuentaNueva();
        btnEventEliminar.setEnabled(false);
    }//GEN-LAST:event_btnCancelarActionPerformed


    private void btnEventEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEventEliminarActionPerformed
        // TODO add your handling code here:
        EventoController borrarEvento = new EventoController();
        borrarEvento.eliminarEventos(codigoESeleccionado);
        limpiarDatosTabla();
        cargarDatosTablaMySQL();
        btnEventEliminar.setEnabled(false);
        btnCancelar.setEnabled(false);
        btnGuardar.setText("NUEVO");
    }//GEN-LAST:event_btnEventEliminarActionPerformed

    private void tablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaMouseClicked
        // TODO add your handling code here:

        int i = tabla.getSelectedRow();
        codigoESeleccionado = (int) tabla.getValueAt(i, 0);

        btnGuardar.setText("ACTUALIZAR");
        btnCancelar.setEnabled(true);
        btnEventEliminar.setEnabled(true);
        //JOptionPane.showMessageDialog(null, i);
        txtNombre.setText(tabla.getValueAt(i, 1).toString());
        txtFecha.setText(tabla.getValueAt(i, 3).toString());
        txtLugar.setText(tabla.getValueAt(i, 6).toString());
        cambioEstado(true);
        txtNombre.requestFocus();


    }//GEN-LAST:event_tablaMouseClicked

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmEventos.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        }
        //</editor-fold>
        //</editor-fold>
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new FrmEventos().setVisible(true);
        });

    }
    private int codigoESeleccionado;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Nombre;
    public javax.swing.JButton btnCancelar;
    public javax.swing.JButton btnEventEliminar;
    public javax.swing.JRadioButton btnEventNo;
    public javax.swing.JRadioButton btnEventSi;
    public javax.swing.JButton btnGuardar;
    public javax.swing.JComboBox<String> cmbAMPMFin;
    public javax.swing.JComboBox<String> cmbAMPMInicio;
    public javax.swing.JComboBox<String> cmbEstado;
    public javax.swing.JComboBox<String> cmbTipo;
    public javax.swing.JComboBox<String> horaFin;
    public javax.swing.JComboBox<String> horaInicio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    public javax.swing.JTable tabla;
    public javax.swing.JEditorPane txtFecha;
    public javax.swing.JEditorPane txtLugar;
    public javax.swing.JEditorPane txtNombre;
    // End of variables declaration//GEN-END:variables
}
